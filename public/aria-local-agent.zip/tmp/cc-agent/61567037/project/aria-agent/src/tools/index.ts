import { Tool } from '../types.js';
import { fileTools } from './file.js';
import { codeTools } from './code.js';
import { webTools } from './web.js';

export const allTools: Tool[] = [
  ...fileTools,
  ...codeTools,
  ...webTools
];

export function getToolByName(name: string): Tool | undefined {
  return allTools.find(t => t.name === name);
}

export function getToolDescriptions(): string {
  return allTools
    .map(t => `- ${t.name}: ${t.description}`)
    .join('\n');
}

export { fileTools, codeTools, webTools };
