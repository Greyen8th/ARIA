import { AgentAction, AgentStep, ExecutionLog, Tool, Message } from '../types.js';
import { OllamaProvider } from '../providers/ollama.js';
import { MultiProviderEngine } from '../providers/multi-provider.js';
import { Memory } from '../memory/index.js';
import { allTools, getToolByName } from '../tools/index.js';
import { v4 as uuid } from 'uuid';

const COST_ERROR_PATTERNS = [
  'quota exceeded',
  'rate limit',
  'payment required',
  'billing',
  'insufficient funds',
  'api key invalid',
  '429',
  '402',
];

export class AgentExecutor {
  private provider: OllamaProvider;
  private multiProvider: MultiProviderEngine;
  private memory: Memory;
  private tools: Tool[];
  private maxIterations: number;
  private verbose: boolean;
  private useMultiProvider: boolean;

  constructor(options: {
    provider: OllamaProvider;
    memory: Memory;
    tools?: Tool[];
    maxIterations?: number;
    verbose?: boolean;
    useMultiProvider?: boolean;
  }) {
    this.provider = options.provider;
    this.multiProvider = new MultiProviderEngine();
    this.memory = options.memory;
    this.tools = options.tools || allTools;
    this.maxIterations = options.maxIterations || 15;
    this.verbose = options.verbose ?? true;
    this.useMultiProvider = options.useMultiProvider ?? true;
  }

  async execute(task: string, onStep?: (step: AgentStep) => void): Promise<string> {
    const startTime = Date.now();
    const steps: AgentStep[] = [];
    let iterations = 0;
    let lastError: string | undefined;
    let currentProvider = 'ollama';

    await this.memory.addUserMessage(task);

    const messages: Message[] = this.memory.getMessages();

    while (iterations < this.maxIterations) {
      iterations++;

      if (this.verbose) {
        console.log(`\n--- Iteration ${iterations}/${this.maxIterations} [${currentProvider}] ---`);
      }

      try {
        let response: string;

        if (this.useMultiProvider) {
          const result = await this.multiProvider.chat(
            messages.map(m => ({ role: m.role, content: m.content })),
            { preferredProvider: currentProvider }
          );
          response = result.content;
          currentProvider = result.provider;

          if (this.verbose) {
            console.log(`Provider used: ${result.provider} (${result.latency}ms)`);
          }
        } else {
          const ollamaResult = await this.provider.chat(messages, this.tools);
          response = ollamaResult;
        }

        if (this.verbose) {
          console.log('LLM Response:', response.slice(0, 500));
        }

        const action = this.parseAction(response);

        if (!action) {
          messages.push({ role: 'assistant', content: response });
          await this.memory.addAssistantMessage(response);

          await this.logExecution(task, steps, response, true, startTime, undefined, currentProvider);
          return response;
        }

        if (action.tool === 'final_answer') {
          const answer = action.params.answer || action.params.response || response;
          await this.memory.addAssistantMessage(answer);

          await this.logExecution(task, steps, answer, true, startTime, undefined, currentProvider);
          return answer;
        }

        if (action.tool === 'search_free_alternatives') {
          const service = action.params.service || action.params.query;
          const alternatives = await this.multiProvider.searchFreeAlternatives(service);
          const observation = `Free alternatives for "${service}":\n${alternatives.map((a, i) => `${i + 1}. ${a}`).join('\n')}`;

          const step: AgentStep = {
            action,
            observation,
            timestamp: Date.now()
          };
          steps.push(step);
          if (onStep) onStep(step);

          messages.push({
            role: 'assistant',
            content: `Searching free alternatives for: ${service}`
          });
          messages.push({
            role: 'tool',
            content: observation,
            toolName: action.tool
          });
          continue;
        }

        const tool = getToolByName(action.tool);
        if (!tool) {
          const errorMsg = `Unknown tool: ${action.tool}. Available tools: ${this.tools.map(t => t.name).join(', ')}`;
          messages.push({
            role: 'tool',
            content: errorMsg,
            toolName: action.tool
          });
          continue;
        }

        if (this.verbose) {
          console.log(`Executing tool: ${action.tool}`);
          console.log('Parameters:', JSON.stringify(action.params, null, 2));
        }

        const observation = await tool.execute(action.params);

        if (this.verbose) {
          console.log('Result:', observation.slice(0, 500));
        }

        const step: AgentStep = {
          action,
          observation,
          timestamp: Date.now()
        };
        steps.push(step);

        if (onStep) {
          onStep(step);
        }

        messages.push({
          role: 'assistant',
          content: `Using tool: ${action.tool}\nReasoning: ${action.reasoning}`
        });
        messages.push({
          role: 'tool',
          content: observation,
          toolName: action.tool
        });

        await this.memory.addToolResult(action.tool, observation);

      } catch (error: any) {
        const errorMsg = error.message || 'Unknown error';
        lastError = errorMsg;

        if (this.isCostRelatedError(errorMsg)) {
          if (this.verbose) {
            console.log(`[ZERO-COST ENGINE] Cost error detected: ${errorMsg}`);
            console.log('[ZERO-COST ENGINE] Switching to alternative provider...');
          }

          const alternatives = await this.multiProvider.searchFreeAlternatives(currentProvider);
          messages.push({
            role: 'system',
            content: `PROVIDER BLOCKED (${lastError}). Switching to alternatives: ${alternatives.join(', ')}. Continue with the task.`
          });
          continue;
        }

        if (this.verbose) {
          console.error('Error:', lastError);
        }
        messages.push({
          role: 'tool',
          content: `Error: ${lastError}`,
          toolName: 'system'
        });
      }
    }

    const errorResult = `Task incomplete after ${this.maxIterations} iterations. Last error: ${lastError || 'Max iterations reached'}`;
    await this.logExecution(task, steps, errorResult, false, startTime, lastError, currentProvider);
    return errorResult;
  }

  private isCostRelatedError(error: string): boolean {
    const lowerError = error.toLowerCase();
    return COST_ERROR_PATTERNS.some(pattern => lowerError.includes(pattern));
  }

  private parseAction(response: string): AgentAction | null {
    try {
      const jsonMatch = response.match(/```json\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[1]);
        if (parsed.action) {
          return {
            tool: parsed.action.tool,
            params: parsed.action.params || {},
            reasoning: parsed.thought || parsed.reasoning || ''
          };
        }
      }

      const directJson = response.match(/\{[\s\S]*"action"[\s\S]*\}/);
      if (directJson) {
        const parsed = JSON.parse(directJson[0]);
        if (parsed.action) {
          return {
            tool: parsed.action.tool,
            params: parsed.action.params || {},
            reasoning: parsed.thought || parsed.reasoning || ''
          };
        }
      }

      return null;
    } catch {
      return null;
    }
  }

  private async logExecution(
    task: string,
    steps: AgentStep[],
    result: string,
    success: boolean,
    startTime: number,
    error?: string,
    provider?: string
  ): Promise<void> {
    const log: ExecutionLog = {
      id: uuid(),
      task,
      steps,
      result,
      success,
      duration: Date.now() - startTime,
      timestamp: Date.now(),
      error,
      provider
    };
    await this.memory.logExecution(log);
  }

  getTools(): Tool[] {
    return this.tools;
  }

  addTool(tool: Tool): void {
    this.tools.push(tool);
  }

  removeTool(name: string): boolean {
    const index = this.tools.findIndex(t => t.name === name);
    if (index >= 0) {
      this.tools.splice(index, 1);
      return true;
    }
    return false;
  }

  getProviderStatus() {
    return this.multiProvider.getProviderStatus();
  }

  getUsageStats() {
    return this.multiProvider.getUsageStats();
  }
}
