import express from 'express';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'http';
import { OllamaProvider } from './providers/ollama.js';
import { Memory } from './memory/index.js';
import { AgentExecutor } from './agent/executor.js';
import { SelfImprovement } from './agent/self-improve.js';
import { allTools } from './tools/index.js';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

let provider: OllamaProvider;
let memory: Memory;
let executor: AgentExecutor;
let selfImprove: SelfImprovement;
let currentModel = 'llama3.2:3b';

async function initializeAgent() {
  provider = new OllamaProvider({
    name: currentModel,
    provider: 'ollama',
    temperature: 0.7,
    contextWindow: 8192
  });

  memory = new Memory('./aria-data', 50);
  await memory.initialize();

  executor = new AgentExecutor({
    provider,
    memory,
    tools: allTools,
    maxIterations: 15,
    verbose: true
  });

  selfImprove = new SelfImprovement(memory, provider, './aria-data');
  await selfImprove.initialize();
}

app.get('/api/status', async (req, res) => {
  const available = await provider.isAvailable();
  const models = available ? await provider.listModels() : [];
  res.json({
    ollama: available,
    currentModel,
    availableModels: models,
    tools: allTools.map(t => ({ name: t.name, description: t.description }))
  });
});

app.get('/api/models', async (req, res) => {
  const models = await provider.listModels();
  res.json({ models });
});

app.post('/api/model', async (req, res) => {
  const { model } = req.body;
  currentModel = model;
  provider = new OllamaProvider({
    name: model,
    provider: 'ollama',
    temperature: 0.7,
    contextWindow: 8192
  });
  executor = new AgentExecutor({
    provider,
    memory,
    tools: allTools,
    maxIterations: 15,
    verbose: true
  });
  res.json({ success: true, model });
});

app.post('/api/pull-model', async (req, res) => {
  const { model } = req.body;
  try {
    await provider.pullModel(model);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/history', async (req, res) => {
  const messages = memory.getMessages();
  res.json({ messages });
});

app.post('/api/clear', async (req, res) => {
  await memory.clear();
  res.json({ success: true });
});

app.get('/api/performance', async (req, res) => {
  const report = await selfImprove.analyzePerformance();
  res.json(report);
});

app.get('/api/improvements', async (req, res) => {
  const suggestions = await selfImprove.suggestImprovements();
  const history = await selfImprove.getImprovementHistory();
  res.json({ suggestions, history });
});

app.get('/api/logs', async (req, res) => {
  const limit = parseInt(req.query.limit as string) || 50;
  const logs = await memory.getExecutionLogs(limit);
  res.json({ logs });
});

wss.on('connection', (ws: WebSocket) => {
  console.log('Client connected');

  ws.on('message', async (data: Buffer) => {
    try {
      const message = JSON.parse(data.toString());

      if (message.type === 'execute') {
        ws.send(JSON.stringify({ type: 'status', status: 'thinking' }));

        const result = await executor.execute(message.task, (step) => {
          ws.send(JSON.stringify({
            type: 'step',
            step: {
              tool: step.action.tool,
              params: step.action.params,
              reasoning: step.action.reasoning,
              result: step.observation.slice(0, 1000)
            }
          }));
        });

        ws.send(JSON.stringify({ type: 'result', result }));
      }
    } catch (error: any) {
      ws.send(JSON.stringify({ type: 'error', error: error.message }));
    }
  });

  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

const PORT = process.env.PORT || 3847;

initializeAgent().then(() => {
  server.listen(PORT, () => {
    console.log(`\n====================================`);
    console.log(`   ARIA Agent Server Running`);
    console.log(`====================================`);
    console.log(`\nOpen http://localhost:${PORT} in your browser`);
    console.log(`\nMake sure Ollama is running: ollama serve`);
    console.log(`\nRecommended models:`);
    console.log(`  - llama3.2:3b (fast, general purpose)`);
    console.log(`  - codellama:7b (coding tasks)`);
    console.log(`  - deepseek-coder:6.7b (advanced coding)`);
    console.log(`  - mistral:7b (balanced)`);
    console.log(`\nTo download a model: ollama pull <model_name>`);
  });
});
