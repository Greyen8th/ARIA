import { ModelConfig, Message, Tool } from '../types.js';
import { buildSystemPrompt } from '../brain/index.js';

export class OllamaProvider {
  private config: ModelConfig;
  private baseUrl: string;

  constructor(config: ModelConfig) {
    this.config = config;
    this.baseUrl = config.baseUrl || 'http://localhost:11434';
  }

  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      return response.ok;
    } catch {
      return false;
    }
  }

  async listModels(): Promise<string[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      const data = await response.json() as { models?: { name: string }[] };
      return data.models?.map(m => m.name) || [];
    } catch {
      return [];
    }
  }

  async pullModel(modelName: string): Promise<void> {
    console.log(`Downloading model ${modelName}...`);
    const response = await fetch(`${this.baseUrl}/api/pull`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: modelName, stream: false })
    });
    if (!response.ok) {
      throw new Error(`Failed to pull model: ${await response.text()}`);
    }
    console.log(`Model ${modelName} ready!`);
  }

  async chat(messages: Message[], tools?: Tool[]): Promise<string> {
    const systemPrompt = buildSystemPrompt(tools || []);

    const formattedMessages = [
      { role: 'system', content: systemPrompt },
      ...messages.map(m => ({
        role: m.role === 'tool' ? 'user' : m.role,
        content: m.role === 'tool'
          ? `[Tool Result - ${m.toolName}]: ${m.content}`
          : m.content
      }))
    ];

    const response = await fetch(`${this.baseUrl}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.config.name,
        messages: formattedMessages,
        stream: false,
        options: {
          temperature: this.config.temperature ?? 0.7,
          num_ctx: this.config.contextWindow ?? 8192,
          num_predict: this.config.maxTokens ?? 4096
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama error: ${await response.text()}`);
    }

    const data = await response.json() as { message?: { content: string } };
    return data.message?.content || '';
  }

  async generate(prompt: string): Promise<string> {
    const response = await fetch(`${this.baseUrl}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.config.name,
        prompt,
        stream: false,
        options: {
          temperature: this.config.temperature ?? 0.7,
          num_ctx: this.config.contextWindow ?? 8192,
          num_predict: this.config.maxTokens ?? 4096
        }
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama error: ${await response.text()}`);
    }

    const data = await response.json() as { response?: string };
    return data.response || '';
  }

}
