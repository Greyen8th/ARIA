import { app, BrowserWindow, shell, dialog, Menu, Tray, nativeImage } from 'electron';
import { spawn, execSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let mainWindow = null;
let serverProcess = null;
let tray = null;
let isQuitting = false;

const PORT = 3847;
const SERVER_URL = `http://localhost:${PORT}`;

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;

function getResourcePath(...paths) {
  if (isDev) {
    return path.join(__dirname, '..', ...paths);
  }
  return path.join(process.resourcesPath, ...paths);
}

function checkOllama() {
  try {
    execSync('curl -s http://localhost:11434/api/tags', { timeout: 3000 });
    return true;
  } catch {
    return false;
  }
}

function startOllama() {
  try {
    const ollamaPath = execSync('which ollama', { encoding: 'utf-8' }).trim();
    if (ollamaPath) {
      spawn(ollamaPath, ['serve'], {
        detached: true,
        stdio: 'ignore'
      }).unref();
      return true;
    }
  } catch {
    return false;
  }
  return false;
}

async function startServer() {
  return new Promise((resolve, reject) => {
    const serverPath = getResourcePath('src', 'server.ts');

    const tsxPath = isDev
      ? path.join(__dirname, '..', 'node_modules', '.bin', 'tsx')
      : path.join(process.resourcesPath, 'node_modules', '.bin', 'tsx');

    const env = {
      ...process.env,
      PORT: PORT.toString(),
      NODE_ENV: isDev ? 'development' : 'production'
    };

    serverProcess = spawn(tsxPath, [serverPath], {
      cwd: getResourcePath(),
      env,
      stdio: ['pipe', 'pipe', 'pipe']
    });

    serverProcess.stdout.on('data', (data) => {
      const output = data.toString();
      console.log('[Server]', output);
      if (output.includes('ARIA Agent Server Running') || output.includes(`localhost:${PORT}`)) {
        resolve();
      }
    });

    serverProcess.stderr.on('data', (data) => {
      console.error('[Server Error]', data.toString());
    });

    serverProcess.on('error', (err) => {
      console.error('[Server Process Error]', err);
      reject(err);
    });

    serverProcess.on('exit', (code) => {
      console.log('[Server] Process exited with code:', code);
      if (!isQuitting) {
        setTimeout(() => startServer(), 2000);
      }
    });

    setTimeout(() => resolve(), 5000);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    backgroundColor: '#0a0a0f',
    titleBarStyle: 'hiddenInset',
    trafficLightPosition: { x: 20, y: 20 },
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    show: false
  });

  mainWindow.loadURL(SERVER_URL);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) {
      mainWindow.webContents.openDevTools();
    }
  });

  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      mainWindow.hide();
      return false;
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

function createTray() {
  const iconPath = path.join(__dirname, '..', 'build', 'tray-icon.png');

  let icon;
  if (fs.existsSync(iconPath)) {
    icon = nativeImage.createFromPath(iconPath);
  } else {
    icon = nativeImage.createEmpty();
  }

  tray = new Tray(icon.resize({ width: 16, height: 16 }));

  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Open ARIA',
      click: () => {
        if (mainWindow) {
          mainWindow.show();
        }
      }
    },
    { type: 'separator' },
    {
      label: 'Check Ollama Status',
      click: () => {
        const isRunning = checkOllama();
        dialog.showMessageBox({
          type: 'info',
          title: 'Ollama Status',
          message: isRunning ? 'Ollama is running' : 'Ollama is not running',
          buttons: isRunning ? ['OK'] : ['OK', 'Start Ollama'],
          defaultId: 0
        }).then((result) => {
          if (result.response === 1) {
            startOllama();
          }
        });
      }
    },
    { type: 'separator' },
    {
      label: 'Quit ARIA',
      click: () => {
        isQuitting = true;
        app.quit();
      }
    }
  ]);

  tray.setToolTip('ARIA - AI Agent');
  tray.setContextMenu(contextMenu);

  tray.on('click', () => {
    if (mainWindow) {
      if (mainWindow.isVisible()) {
        mainWindow.focus();
      } else {
        mainWindow.show();
      }
    }
  });
}

function createMenu() {
  const template = [
    {
      label: app.name,
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        {
          label: 'Check for Updates...',
          enabled: false
        },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide' },
        { role: 'hideOthers' },
        { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Window',
      submenu: [
        { role: 'minimize' },
        { role: 'zoom' },
        { type: 'separator' },
        { role: 'front' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'ARIA Documentation',
          click: () => shell.openExternal('https://github.com/aria-agent')
        },
        {
          label: 'Ollama Website',
          click: () => shell.openExternal('https://ollama.ai')
        }
      ]
    }
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

async function showOllamaDialog() {
  const result = await dialog.showMessageBox({
    type: 'warning',
    title: 'Ollama Required',
    message: 'Ollama is not running',
    detail: 'ARIA requires Ollama to run AI models locally. Would you like to start Ollama or continue anyway?',
    buttons: ['Start Ollama', 'Download Ollama', 'Continue Anyway'],
    defaultId: 0
  });

  if (result.response === 0) {
    const started = startOllama();
    if (!started) {
      dialog.showErrorBox('Error', 'Could not start Ollama. Please start it manually.');
    } else {
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  } else if (result.response === 1) {
    shell.openExternal('https://ollama.ai');
  }
}

app.whenReady().then(async () => {
  createMenu();

  const ollamaRunning = checkOllama();
  if (!ollamaRunning) {
    await showOllamaDialog();
  }

  try {
    await startServer();
  } catch (err) {
    console.error('Failed to start server:', err);
    dialog.showErrorBox('Error', 'Failed to start ARIA server. Please try again.');
    app.quit();
    return;
  }

  createWindow();
  createTray();

  app.on('activate', () => {
    if (mainWindow === null) {
      createWindow();
    } else {
      mainWindow.show();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  isQuitting = true;
  if (serverProcess) {
    serverProcess.kill();
  }
});

app.on('quit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
});
